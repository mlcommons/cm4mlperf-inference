| Model   | Scenario   |   Accuracy |   Throughput | Latency (in ms)   |
|---------|------------|------------|--------------|-------------------|
| bert-99 | offline    |    90.8749 |       48.312 | -                 |